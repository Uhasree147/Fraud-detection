import zipfile
import os
import pandas as pd
from sklearn.preprocessing import StandardScaler
from imblearn.over_sampling import SMOTE
from sklearn.ensemble import RandomForestClassifier, IsolationForest
import xgboost as xgb
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense
import numpy as np

# Step 1: **Data Collection**
# Define paths and extract ZIP file
zip_file_path = "archive (1).zip"
extract_folder = "extracted_data"

# Extract the ZIP file
with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
    zip_ref.extractall(extract_folder)

# Find extracted CSV file
csv_file_path = os.path.join(extract_folder, "creditcard.csv")

# Load the dataset
df = pd.read_csv(csv_file_path)

# Step 2: **Data Preprocessing**
# Separate features (X) and target (y)
X = df.drop(columns=['Class'])
y = df['Class']

# Normalize continuous features (V1 to V28, Amount)
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Handle class imbalance using SMOTE
smote = SMOTE(sampling_strategy='auto', random_state=42)
X_resampled, y_resampled = smote.fit_resample(X_scaled, y)

# Step 3: **Model Training**
# Train Random Forest model
rf_model = RandomForestClassifier(n_estimators=100, class_weight='balanced', random_state=42)
rf_model.fit(X_resampled, y_resampled)

# Train XGBoost model
xgb_model = xgb.XGBClassifier(scale_pos_weight=15, random_state=42)
xgb_model.fit(X_resampled, y_resampled)

# Train Isolation Forest model
if_model = IsolationForest(contamination=0.01, random_state=42)
if_model.fit(X_resampled)

# Step 4: **Model Evaluation**
# Make predictions with each model (assuming X_test and y_test exist as the test dataset)
rf_preds = rf_model.predict(X_resampled)  # replace X_resampled with your actual test set
xgb_preds = xgb_model.predict(X_resampled)  # replace X_resampled with your actual test set
if_preds = if_model.predict(X_resampled)  # replace X_resampled with your actual test set

# For Isolation Forest, you might want to treat -1 as fraud (anomaly) and 1 as normal
if_preds = [1 if x == -1 else 0 for x in if_preds]

# Classification report
print("Random Forest Classification Report:")
print(classification_report(y_resampled, rf_preds))

print("XGBoost Classification Report:")
print(classification_report(y_resampled, xgb_preds))

# Confusion Matrix
print("Random Forest Confusion Matrix:")
print(confusion_matrix(y_resampled, rf_preds))

print("XGBoost Confusion Matrix:")
print(confusion_matrix(y_resampled, xgb_preds))

# Accuracy Score
print("Random Forest Accuracy:", accuracy_score(y_resampled, rf_preds))
print("XGBoost Accuracy:", accuracy_score(y_resampled, xgb_preds))

# Step 5: **Anomaly Detection (Isolation Forest and Autoencoder)**

# Anomaly detection using Isolation Forest
anomaly_preds = if_model.predict(X_scaled)
anomaly_preds = [1 if x == -1 else 0 for x in anomaly_preds]
df['Anomaly_Prediction'] = anomaly_preds

# Autoencoder-based Anomaly Detection
# Define autoencoder architecture
input_layer = Input(shape=(X_scaled.shape[1],))
encoded = Dense(64, activation='relu')(input_layer)
decoded = Dense(X_scaled.shape[1], activation='sigmoid')(encoded)

autoencoder = Model(input_layer, decoded)
autoencoder.compile(optimizer='adam', loss='mean_squared_error')

# Train the Autoencoder
autoencoder.fit(X_scaled, X_scaled, epochs=50, batch_size=256, shuffle=True)

# Get reconstruction errors
reconstructed = autoencoder.predict(X_scaled)
reconstruction_errors = ((X_scaled - reconstructed) ** 2).mean(axis=1)

# Define a threshold for anomaly detection
threshold = reconstruction_errors.mean() + 3 * reconstruction_errors.std()

# Mark anomalies based on reconstruction error threshold
autoencoder_anomalies = reconstruction_errors > threshold
df['Autoencoder_Anomaly'] = autoencoder_anomalies

# Step 6: **Results**
# Display a few rows of the dataset with anomaly predictions
print(df[['Time', 'Amount', 'Class', 'Anomaly_Prediction', 'Autoencoder_Anomaly']].head())

# Optional: Save the processed dataset with predictions
df.to_csv("processed_creditcard_data.csv", index=False)



